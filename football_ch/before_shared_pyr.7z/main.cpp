#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>

struct Player;
struct Team;
struct Match;

class Member {
public:
    uint32_t id;

    virtual void serialize(std::ostream &) = 0;
};


struct Team : Member {
    std::string name;
    std::vector<Player *> players;
    std::vector<uint32_t> id_players;

    Team(std::istream &in) {
        in >> id >> name;
        std::string tmp;
        std::getline(in, tmp);
        std::stringstream inbuf(tmp);
        int id;
        while (inbuf >> id) {
            id_players.push_back(id);
        }
    }

    void serialize(std::ostream &out) override;

};


struct Match : Member {
    std::string data;
    std::string location;
    std::string result;
    Team *team1;
    Team *team2;
    std::vector<uint32_t> id_teams;
    std::vector<Player *> players;
    std::vector<uint32_t> id_players;

    Match(std::istream &in) {
        uint32_t id_team1;
        uint32_t id_team2;
        in >> id >> data >> location >> result >> id_team1 >> id_team2;
        id_teams.push_back(id_team1);
        id_teams.push_back(id_team2);
        std::string tmp;
        std::getline(in, tmp);
        std::stringstream inbuf(tmp);
        int id;
        while (inbuf >> id) {
            id_players.push_back(id);
        }
    }

    void serialize(std::ostream &out) override;
};

struct Player : Member {
    std::string name;
    Team *team;
    Match *match;
    uint32_t team_id;

    Player(std::istream &in) {
        in >> id >> name >> team_id;
    }

    void serialize(std::ostream &out) override;
};

void Match::serialize(std::ostream &out) {
    out << "match" << '\t'
        << id << '\t'
        << data << '\t'
        << location << '\t'
        << result << '\t'
        << id_teams[0] << '\t'
        << id_teams[1] << '\t';
    for (const auto *player : players) {
        out << player->id << '\t';
    }
    out << std::endl;
}

void Team::serialize(std::ostream &out) {
    out << "team" << '\t'
        << id << '\t'
        << name << '\t';
    for (const auto *player : players) {
        out << player->id << '\t';
    }
    out << std::endl;
}

void Player::serialize(std::ostream &out) {
    out << "player" << '\t'
        << id << '\t'
        << name << '\t'
        << team_id << std::endl;
}

struct Creator {
    virtual Member *factoryMethod(std::istream &) = 0;
};

struct PlayerCreator : Creator {
    inline Player *factoryMethod(std::istream &in) { return new Player(in); }
};

struct TeamCreator : Creator {
    inline Team *factoryMethod(std::istream &in) { return new Team(in); }
};

struct MatchCreator : Creator {
    inline Match *factoryMethod(std::istream &in) { return new Match(in); }
};

struct Championship{
    void mainMethod();
};

void Championship::mainMethod(){
    std::ifstream in("data.tsv");
    std::string type;
    PlayerCreator pCreator;
    TeamCreator tCreator;
    MatchCreator mCreator;

    /* std::vector<std::shared_ptr<Player>> players;
     std::vector<std::shared_ptr<Team>> teams;
     std::vector<std::shared_ptr<Match>> matches;*/

    std::vector<Player *> players;
    std::vector<Team *> teams;
    std::vector<Match *> matches;

    while (in >> type) {
        if (type == "team") {
            teams.push_back(tCreator.factoryMethod(in));
        } else if (type == "player") {
            players.push_back(pCreator.factoryMethod(in));
        } else if (type == "match") {
            matches.push_back(mCreator.factoryMethod(in));
        }
    }

    for (Player *player : players) {
        for (Team *team : teams) {
            if (player->team_id == team->id) {
                player->team = team;
                break;
            }
        }
    }

    for (Team *team : teams) {
        for (uint32_t id : team->id_players) {
            for (Player *player : players) {
                if (player->id == id) {
                    team->players.push_back(player);
                    break;
                }
            }
        }
    }


    for (Match *match : matches) {

        for (Team *team : teams) {
            if (match->id_teams[0] == team->id) {
                match->team1 = team;
                break;
            } else if (match->id_teams[1] == team->id) {
                match->team2 = team;
                break;
            }
        }

        for (uint32_t id : match->id_players) {
            for (Player *player : players) {
                if (player->id == id) {
                    match->players.push_back(player);
                    break;
                }
            }
        }
    }

    std::ofstream tout("teams.tsv");

    for (auto &team: teams) {
        team->serialize(tout);
    }

    std::ofstream pout("players.tsv");

    for (auto &player: players) {
        player->serialize(pout);
    }

    std::ofstream mout("matches.tsv");
    for (auto &match: matches) {
        match->serialize(mout);
    }

}

int main() {
    Championship a;
    a.mainMethod();
    return 0;
}